//
//  Nessie-iOS-Wrapper.h
//  Nessie-iOS-Wrapper
//
//  Created by Mecklenburg, William on 4/3/15.
//  Copyright (c) 2015 Nessie. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Nessie-iOS-Wrapper.
FOUNDATION_EXPORT double Nessie_iOS_WrapperVersionNumber;

//! Project version string for Nessie-iOS-Wrapper.
FOUNDATION_EXPORT const unsigned char Nessie_iOS_WrapperVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Nessie_iOS_Wrapper/PublicHeader.h>



//
//  TabViewController.swift
//  Nessie-iOS-Wrapper
//
//  Created by Lopez Vargas, Victor R. on 9/16/16.
//  Copyright © 2016 Nessie. All rights reserved.
//

import UIKit

class TabViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

}
